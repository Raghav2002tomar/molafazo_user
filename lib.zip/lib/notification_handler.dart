import 'dart:async';
import 'dart:convert';
import 'package:ecom/services/auth_service.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

import 'main.dart'; // 👈 Import your AuthStorage


// // Background message handler must be a top-level function
Future<void> firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  print("----------- 🌙 FULL FCM MESSAGE (BACKGROUND) ------------");
  print("ID: ${message.messageId}");
  print("Title: ${message.notification?.title}");
  print("Body: ${message.notification?.body}");
  print("Data: ${message.data}");
  print("---------------------------------------------------------");
}

class NotificationHandler {
  static final NotificationHandler _instance =
  NotificationHandler._internal();
  factory NotificationHandler() => _instance;
  NotificationHandler._internal();

  final FirebaseMessaging _firebaseMessaging = FirebaseMessaging.instance;
  final FlutterLocalNotificationsPlugin _flutterLocalNotificationsPlugin =
  FlutterLocalNotificationsPlugin();

  bool _notificationHandled = false;

  Future<void> init(BuildContext context) async {
    await _firebaseMessaging.requestPermission();

    const androidInit = AndroidInitializationSettings('@mipmap/ic_launcher');
    const iOSInit = DarwinInitializationSettings();

    const initSettings =
    InitializationSettings(android: androidInit, iOS: iOSInit);

    await _flutterLocalNotificationsPlugin.initialize(
      settings: initSettings,
      onDidReceiveNotificationResponse: (details) {
        _handleNotificationClick(details.payload);
      },
    );

    // ✅ ADD THIS BLOCK
    const AndroidNotificationChannel channel = AndroidNotificationChannel(
      'default_channel',
      'General Notifications',
      description: 'This channel is used for general notifications.',
      importance: Importance.max,
    );

    await _flutterLocalNotificationsPlugin
        .resolvePlatformSpecificImplementation<
        AndroidFlutterLocalNotificationsPlugin>()
        ?.createNotificationChannel(channel);

    await _fetchAndSaveFcmToken();

    FirebaseMessaging.onMessage.listen((message) {
      print("Foreground message received");
      _showLocalNotification(message);
    });

    FirebaseMessaging.onMessageOpenedApp.listen((message) {
      print("Background message opened");
      _openInterestedPassenger(message.data);
    });

    final initialMessage =
    await FirebaseMessaging.instance.getInitialMessage();

    if (initialMessage != null) {
      print("App opened from terminated state");
      _openInterestedPassenger(initialMessage.data);
    }
  }

  // 🔀 ROUTING
  void _openInterestedPassenger(Map<String, dynamic> data) {
    final type = data['notification_type']?.toString() ?? "";

    print("🔔 TYPE: $type");
    print("📦 DATA: $data");
    //
    // if (type == "4") {
    //   navigatorKey.currentState?.push(
    //     MaterialPageRoute(builder: (_) => Viewresponcescreen(initialTabIndex: 0)),
    //   );
    // } if (type == "1"|| type == "3") {
    //   navigatorKey.currentState?.push(
    //     MaterialPageRoute(builder: (_) => Viewresponcescreen(initialTabIndex: 0)),
    //   );
    // }
    // else if (type == "2") {
    //   navigatorKey.currentState?.push(
    //     MaterialPageRoute(builder: (_) => Chatlistscreen()),
    //   );
    // } else if (type == "99" || type == "100") {
    //   navigatorKey.currentState?.push(
    //     MaterialPageRoute(
    //       builder: (_) => NewsDetailScreen(
    //         notification: AppNotification(
    //           id: 0,
    //           title: data['title'] ?? "",
    //           description: data['body'] ?? "",
    //           type: int.parse(type),
    //           createdAt: DateTime.now().toString(),
    //         ),
    //       ),
    //     ),
    //   );
    // }
  }

  // 🔔 SHOW LOCAL
  Future<void> _showLocalNotification(RemoteMessage message) async {
    final notification = message.notification;

    if (notification == null) return;

    const androidDetails = AndroidNotificationDetails(
      'default_channel',
      'General Notifications',
      importance: Importance.max,
      priority: Priority.high,
      playSound: true,
    );

    const details = NotificationDetails(android: androidDetails);

    await _flutterLocalNotificationsPlugin.show(
      id: message.hashCode,   // ✅ REQUIRED named parameter
      title: notification.title,
      body: notification.body,
      notificationDetails: details,
    );

  }

  void _handleNotificationClick(String? payload) {
    if (payload == null) return;
    final data = jsonDecode(payload);
    _openInterestedPassenger(data);
  }

  Future<void> _fetchAndSaveFcmToken() async {
    final token = await _firebaseMessaging.getToken();
    if (token != null) {
      print("fcm token ===== ${token}");
      await AuthStorage.saveFcmToken(token);
    }
  }
}
