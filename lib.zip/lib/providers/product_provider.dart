import 'package:flutter/material.dart';
import '../models/product.dart';
import '../services/api_service.dart';

class ProductProvider extends ChangeNotifier {
  List<Product> _products = [];
  bool _isLoading = false;
  String? _error;

  List<Product> get products => _products;
  bool get isLoading => _isLoading;
  String? get error => _error;

  Future<void> fetchProducts() async {
    // _isLoading = true;
    // _error = null;
    // notifyListeners();
    //
    // try {
    //   _products = await ApiService.fetchProducts();
    // } catch (e) {
    //   _error = e.toString();
    // } finally {
    //   _isLoading = false;
    //   notifyListeners();
    // }
  }

  Product? getProductById(int id) {
    try {
      return _products.firstWhere((product) => product.id == id);
    } catch (e) {
      return null;
    }
  }
}
