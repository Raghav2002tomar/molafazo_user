import 'package:ecom/services/api_service.dart';
import 'package:flutter/material.dart';
import 'package:shimmer/shimmer.dart';

import '../product/all_products_screen.dart';
import '../product/product_details_screen.dart';
import '../product/store_detail_screen.dart';
import '../search/product_search_screen.dart';
import 'controller/BannerService.dart';
import 'controller/category_service.dart';
import 'controller/product_services.dart';

import 'controller/store_services.dart';
import 'model/Banner_Model.dart';
import 'model/category_model.dart';
import 'model/product_model.dart';
import 'model/store_model.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final ValueNotifier<int?> selectedCategoryId = ValueNotifier(null);
  final ValueNotifier<int?> selectedSubCategoryId = ValueNotifier(null);
  final ValueNotifier<int?> selectedChildCategoryId = ValueNotifier(null);

  final ValueNotifier<List<ProductModel>> products = ValueNotifier([]);
  final ValueNotifier<bool> isLoading = ValueNotifier(true);

  @override
  void initState() {
    super.initState();
    _fetchAllProducts();
  }

  /// Fetch all products initially
  Future<void> _fetchAllProducts() async {
    try {
      isLoading.value = true;
      final result = await ProductService.fetchAllProducts();
      products.value = result;
    } catch (e) {
      products.value = [];
      debugPrint("Error fetching products: $e");
    } finally {
      isLoading.value = false;
    }
  }

  /// Fetch filtered products when category/subcategory/child selected
  Future<void> _fetchFilteredProducts() async {
    try {
      isLoading.value = true;
      final result = await ProductService.fetchProducts(
        categoryId: selectedCategoryId.value,
        subCategoryId: selectedSubCategoryId.value,
        childCategoryId: selectedChildCategoryId.value,
      );
      products.value = result;
    } catch (e) {
      products.value = [];
      debugPrint("Error fetching filtered products: $e");
    } finally {
      isLoading.value = false;
    }
  }

  /// Clear all filters
  void _clearFilters() {
    selectedCategoryId.value = null;
    selectedSubCategoryId.value = null;
    selectedChildCategoryId.value = null;
    _fetchAllProducts();
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final tt = Theme.of(context).textTheme;
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      body: SafeArea(
        child: CustomScrollView(
          slivers: [
            /// HEADER
            SliverAppBar(
              automaticallyImplyLeading: false,
              pinned: true,
              elevation: 0,
              backgroundColor: cs.surface,
              title:InkWell(
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => const ProductSearchScreen(),
                    ),
                  );
                },
                child: Padding(
                  padding: const EdgeInsets.all(0),
                  child: Row(
                    children: [
                      // 🔍 Search Box
                      Expanded(
                        child: InkWell(
                          borderRadius: BorderRadius.circular(24),
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => const ProductSearchScreen(),
                              ),
                            );
                          },
                          child: Container(
                            height: 48,
                            padding: const EdgeInsets.symmetric(horizontal: 16),
                            decoration: BoxDecoration(
                              color: cs.surfaceContainerHighest,
                              borderRadius: BorderRadius.circular(24),
                            ),
                            child: Row(
                              children: [
                                Icon(Icons.search, color: cs.onSurfaceVariant),
                                const SizedBox(width: 8),
                                Text(
                                  "Search products...",
                                  style: tt.bodyMedium?.copyWith(
                                    color: cs.onSurfaceVariant,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),


                      const SizedBox(width: 12),

                      // ⚙️ Filter Button
                      InkWell(onTap: (){
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => const AllProductsScreen(),
                          ),
                        );
                      },
                        child: Container(
                          height: 40,
                          width: 40,
                          decoration: BoxDecoration(
                            color: isDark ? Colors.white : Colors.black,
                            borderRadius: BorderRadius.circular(24),
                            boxShadow: [
                              BoxShadow(
                                color: cs.shadow.withOpacity(0.08),
                                blurRadius: 12,
                                offset: const Offset(0, 4),
                              ),
                            ],
                          ),
                          child: Icon(
                            Icons.menu,
                            color: isDark ? Colors.black : Colors.white,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            const SliverToBoxAdapter(child: SizedBox(height: 12)),

            /// BANNERS
            SliverToBoxAdapter(
              child: SizedBox(
                height: 200, // 🔥 Bigger banner
                child: FutureBuilder<List<BannerModel>>(
                  future: BannerService.fetchBanners(),
                  builder: (_, snapshot) {
                    if (snapshot.connectionState == ConnectionState.waiting) {
                      return const _PromoBannerShimmer();
                    }

                    if (!snapshot.hasData || snapshot.data!.isEmpty) {
                      return const SizedBox();
                    }

                    return _AutoBannerSlider(banners: snapshot.data!);
                  },
                ),
              ),
            ),


            const SliverToBoxAdapter(child: SizedBox(height: 8)),

            /// FILTER BREADCRUMB & CLEAR BUTTON
            ValueListenableBuilder<int?>(
              valueListenable: selectedCategoryId,
              builder: (_, catId, __) {
                if (catId == null)
                  return const SliverToBoxAdapter(child: SizedBox());

                return SliverToBoxAdapter(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 16,
                      vertical: 8,
                    ),
                    child: Row(
                      children: [
                        Expanded(
                          child: _FilterBreadcrumb(
                            selectedCategoryId: selectedCategoryId,
                            selectedSubCategoryId: selectedSubCategoryId,
                            selectedChildCategoryId: selectedChildCategoryId,
                          ),
                        ),
                        const SizedBox(width: 8),
                        _ClearFilterButton(onClear: _clearFilters),
                      ],
                    ),
                  ),
                );
              },
            ),

            /// MAIN CATEGORIES
            // SliverToBoxAdapter(
            //   child: Padding(
            //     padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
            //     child: Row(
            //       children: [
            //         Icon(Icons.category_outlined, size: 18, color: cs.primary),
            //         const SizedBox(width: 6),
            //         Text(
            //           "Categories",
            //           style: tt.titleSmall?.copyWith(
            //             fontWeight: FontWeight.w700,
            //             color: cs.onSurface,
            //           ),
            //         ),
            //         const Spacer(),
            //         TextButton(
            //           onPressed: () {
            //             Navigator.push(
            //               context,
            //               MaterialPageRoute(
            //                 builder: (_) => const AllProductsScreen(),
            //               ),
            //             );
            //           },
            //           child: Text(
            //             "See all",
            //             style: tt.labelLarge?.copyWith(
            //               color: cs.primary,
            //               fontWeight: FontWeight.w600,
            //             ),
            //           ),
            //         ),
            //       ],
            //     ),
            //   ),
            // ),

            // SliverToBoxAdapter(
            //   child: SizedBox(
            //     height: 80, // ✅ MUST be >= chip height
            //
            //     child: FutureBuilder<List<CategoryModel>>(
            //       future: CategoryService.fetchCategories(),
            //       builder: (_, snapshot) {
            //         if (!snapshot.hasData) return const SizedBox();
            //
            //         return ListView.separated(
            //           padding: const EdgeInsets.symmetric(horizontal: 16),
            //           scrollDirection: Axis.horizontal,
            //           itemCount: snapshot.data!.length,
            //           separatorBuilder: (_, __) => const SizedBox(width: 12),
            //           itemBuilder: (_, i) {
            //             final cat = snapshot.data![i];
            //             return GestureDetector(
            //               onTap: () {
            //                 selectedCategoryId.value = cat.id;
            //                 selectedSubCategoryId.value = null;
            //                 selectedChildCategoryId.value = null;
            //                 _fetchFilteredProducts();
            //               },
            //               child: ValueListenableBuilder<int?>(
            //                 valueListenable: selectedCategoryId,
            //                 builder: (_, id, __) {
            //                   return _CompactBigCategoryChip(
            //                     image: cat.image,
            //                     label: cat.name,
            //                     selected: id == cat.id,
            //                   );
            //                 },
            //               ),
            //             );
            //           },
            //         );
            //       },
            //     ),
            //   ),
            // ),
            //
            // /// SUB CATEGORIES
            // ValueListenableBuilder<int?>(
            //   valueListenable: selectedCategoryId,
            //   builder: (_, catId, __) {
            //     if (catId == null) {
            //       return const SliverToBoxAdapter(child: SizedBox());
            //     }
            //
            //     return SliverToBoxAdapter(
            //       child: FutureBuilder<List<CategoryModel>>(
            //         future: CategoryService.fetchCategories(),
            //         builder: (_, snapshot) {
            //           if (!snapshot.hasData) return const SizedBox();
            //
            //           final category = snapshot.data!.firstWhere(
            //             (c) => c.id == catId,
            //           );
            //
            //           if (category.subCategories.isEmpty) {
            //             return const SizedBox();
            //           }
            //
            //           return Column(
            //             crossAxisAlignment: CrossAxisAlignment.start,
            //             children: [
            //               // Padding(
            //               //   padding: const EdgeInsets.only(left: 16, top: 12, bottom: 8),
            //               //   child: Row(
            //               //     children: [
            //               //       Icon(Icons.subdirectory_arrow_right,
            //               //           size: 16, color: cs.primary),
            //               //       const SizedBox(width: 6),
            //               //       Text(
            //               //         "Sub Categories",
            //               //         style: tt.labelLarge?.copyWith(
            //               //           fontWeight: FontWeight.w600,
            //               //           color: cs.onSurface.withOpacity(0.8),
            //               //         ),
            //               //       ),
            //               //     ],
            //               //   ),
            //               // ),
            //               SizedBox(height: 8),
            //               SizedBox(
            //                 height: 36,
            //                 child: ListView.separated(
            //                   padding: const EdgeInsets.symmetric(
            //                     horizontal: 16,
            //                   ),
            //                   scrollDirection: Axis.horizontal,
            //                   itemBuilder: (_, i) {
            //                     final sub = category.subCategories[i];
            //                     return GestureDetector(
            //                       onTap: () {
            //                         selectedSubCategoryId.value = sub.id;
            //                         selectedChildCategoryId.value = null;
            //                         _fetchFilteredProducts();
            //                       },
            //                       child: ValueListenableBuilder<int?>(
            //                         valueListenable: selectedSubCategoryId,
            //                         builder: (_, id, __) {
            //                           return _CompactCategoryChip(
            //                             label: sub.name,
            //                             selected: id == sub.id,
            //                             isSecondary: true,
            //                           );
            //                         },
            //                       ),
            //                     );
            //                   },
            //                   separatorBuilder: (_, __) =>
            //                       const SizedBox(width: 8),
            //                   itemCount: category.subCategories.length,
            //                 ),
            //               ),
            //             ],
            //           );
            //         },
            //       ),
            //     );
            //   },
            // ),
            //
            // /// CHILD CATEGORIES
            // ValueListenableBuilder<int?>(
            //   valueListenable: selectedSubCategoryId,
            //   builder: (_, subId, __) {
            //     if (subId == null) {
            //       return const SliverToBoxAdapter(child: SizedBox());
            //     }
            //
            //     return SliverToBoxAdapter(
            //       child: FutureBuilder<List<CategoryModel>>(
            //         future: CategoryService.fetchCategories(),
            //         builder: (_, snapshot) {
            //           if (!snapshot.hasData) return const SizedBox();
            //
            //           final sub = snapshot.data!
            //               .expand((c) => c.subCategories)
            //               .firstWhere((s) => s.id == subId);
            //
            //           if (sub.childCategories.isEmpty) {
            //             return const SizedBox();
            //           }
            //
            //           return Column(
            //             crossAxisAlignment: CrossAxisAlignment.start,
            //             children: [
            //               SizedBox(height: 8),
            //               SizedBox(
            //                 height: 34,
            //                 child: ListView.separated(
            //                   padding: const EdgeInsets.symmetric(
            //                     horizontal: 16,
            //                   ),
            //                   scrollDirection: Axis.horizontal,
            //                   itemBuilder: (_, i) {
            //                     final child = sub.childCategories[i];
            //                     return GestureDetector(
            //                       onTap: () {
            //                         selectedChildCategoryId.value = child.id;
            //                         _fetchFilteredProducts();
            //                       },
            //                       child: ValueListenableBuilder<int?>(
            //                         valueListenable: selectedChildCategoryId,
            //                         builder: (_, id, __) {
            //                           return _CompactCategoryChip(
            //                             label: child.name,
            //                             selected: id == child.id,
            //                             isChild: true,
            //                           );
            //                         },
            //                       ),
            //                     );
            //                   },
            //                   separatorBuilder: (_, __) =>
            //                       const SizedBox(width: 8),
            //                   itemCount: sub.childCategories.length,
            //                 ),
            //               ),
            //             ],
            //           );
            //         },
            //       ),
            //     );
            //   },
            // ),

            const SliverToBoxAdapter(child: SizedBox(height: 12)),

            /// PRODUCTS SECTION HEADER
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
                child: Row(
                  children: [
                    Icon(
                      Icons.shopping_bag_outlined,
                      size: 18,
                      color: cs.primary,
                    ),
                    const SizedBox(width: 6),
                    Text(
                      "Products",
                      style: tt.titleSmall?.copyWith(
                        fontWeight: FontWeight.w700,
                        color: cs.onSurface,
                      ),
                    ),
                    const Spacer(),
                    const Spacer(),
                    ValueListenableBuilder<List<ProductModel>>(
                      valueListenable: products,
                      builder: (_, list, __) {
                        return InkWell(onTap: (){
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => const AllProductsScreen(),
                            ),
                          );
                        },
                          child: Text(
                            "see all",
                            style: tt.labelMedium?.copyWith(
                              // color: cs.onSurface.withOpacity(0.6),
                            ),
                          ),
                        );
                      },
                    ),
                  ],
                ),
              ),
            ),

            /// PRODUCTS GRID
            ValueListenableBuilder<bool>(
              valueListenable: isLoading,
              builder: (_, loading, __) {
                if (loading) return const _ProductGridShimmer();

                return ValueListenableBuilder<List<ProductModel>>(
                  valueListenable: products,
                  builder: (_, list, __) {
                    if (list.isEmpty) {
                      return SliverToBoxAdapter(
                        child: Padding(
                          padding: const EdgeInsets.all(40),
                          child: Column(
                            children: [
                              Icon(
                                Icons.inventory_2_outlined,
                                size: 64,
                                color: cs.onSurface.withOpacity(0.3),
                              ),
                              const SizedBox(height: 12),
                              Text(
                                "No products found",
                                style: tt.bodyLarge?.copyWith(
                                  color: cs.onSurface.withOpacity(0.5),
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    }

                    return SliverPadding(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      sliver: SliverGrid(
                        gridDelegate:
                        const SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 2,
                          mainAxisSpacing: 10,
                          crossAxisSpacing: 10,
                          childAspectRatio: 0.75,
                        ),
                        delegate: SliverChildBuilderDelegate(
                              (_, i) => _ProductCardCompact(product: list[i]),
                          childCount: list.length > 6
                              ? 6
                              : list.length, // 👈 LIMIT
                        ),
                      ),
                    );
                  },
                );
              },
            ),

            /// STORES HEADER
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
                child: Row(
                  children: [
                    Icon(
                      Icons.storefront,
                      size: 18,
                      color: Theme.of(context).colorScheme.primary,
                    ),
                    const SizedBox(width: 6),
                    Text(
                      "Stores",
                      style: Theme.of(context).textTheme.titleSmall?.copyWith(
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ],
                ),
              ),
            ),

            /// STORES LIST
            SliverToBoxAdapter(
              child: SizedBox(
                height: 220,
                child: FutureBuilder(
                  future: StoreService.fetchStores(),
                  builder: (context, snapshot) {
                    if (snapshot.connectionState == ConnectionState.waiting) {
                      return ListView.separated(
                        padding: const EdgeInsets.symmetric(horizontal: 16),
                        scrollDirection: Axis.horizontal,
                        itemBuilder: (_, __) => Shimmer.fromColors(
                          baseColor: Colors.grey.shade300,
                          highlightColor: Colors.grey.shade100,
                          child: Container(
                            width: 220,
                            decoration: BoxDecoration(
                              color: Colors.grey,
                              borderRadius: BorderRadius.circular(14),
                            ),
                          ),
                        ),
                        separatorBuilder: (_, __) => const SizedBox(width: 12),
                        itemCount: 3,
                      );
                    }

                    if (!snapshot.hasData || snapshot.data!.isEmpty) {
                      return const Center(child: Text("No stores available"));
                    }

                    final stores = snapshot.data!;

                    return ListView.separated(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      scrollDirection: Axis.horizontal,
                      itemBuilder: (_, i) => _StoreCard(store: stores[i]),
                      separatorBuilder: (_, __) => const SizedBox(width: 12),
                      itemCount: stores.length,
                    );
                  },
                ),
              ),
            ),

            const SliverToBoxAdapter(child: SizedBox(height: 40)),
          ],
        ),
      ),
    );
  }
}

/// ------------------------------
/// FILTER BREADCRUMB
/// ------------------------------
class _FilterBreadcrumb extends StatelessWidget {
  final ValueNotifier<int?> selectedCategoryId;
  final ValueNotifier<int?> selectedSubCategoryId;
  final ValueNotifier<int?> selectedChildCategoryId;

  const _FilterBreadcrumb({
    required this.selectedCategoryId,
    required this.selectedSubCategoryId,
    required this.selectedChildCategoryId,
  });

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final tt = Theme.of(context).textTheme;

    return FutureBuilder<List<CategoryModel>>(
      future: CategoryService.fetchCategories(),
      builder: (_, snapshot) {
        if (!snapshot.hasData) return const SizedBox();

        final categories = snapshot.data!;
        String breadcrumb = "";

        if (selectedCategoryId.value != null) {
          final cat = categories.firstWhere(
                (c) => c.id == selectedCategoryId.value,
          );
          breadcrumb = cat.name;

          if (selectedSubCategoryId.value != null) {
            final sub = cat.subCategories.firstWhere(
                  (s) => s.id == selectedSubCategoryId.value,
            );
            breadcrumb += " > ${sub.name}";

            if (selectedChildCategoryId.value != null) {
              final child = sub.childCategories.firstWhere(
                    (c) => c.id == selectedChildCategoryId.value,
              );
              breadcrumb += " > ${child.name}";
            }
          }
        }

        return Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
          decoration: BoxDecoration(
            color: cs.primaryContainer.withOpacity(0.3),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: cs.primary.withOpacity(0.3)),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.filter_list, size: 14, color: cs.primary),
              const SizedBox(width: 6),
              Flexible(
                child: Text(
                  breadcrumb,
                  style: tt.labelSmall?.copyWith(
                    color: cs.primary,
                    fontWeight: FontWeight.w600,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

/// ------------------------------
/// CLEAR FILTER BUTTON
/// ------------------------------
class _ClearFilterButton extends StatelessWidget {
  final VoidCallback onClear;
  const _ClearFilterButton({required this.onClear});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;

    return InkWell(
      onTap: onClear,
      borderRadius: BorderRadius.circular(20),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        decoration: BoxDecoration(
          color: cs.errorContainer.withOpacity(0.2),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: cs.error.withOpacity(0.3)),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.close, size: 14, color: cs.error),
            const SizedBox(width: 4),
            Text(
              "Clear",
              style: TextStyle(
                fontSize: 11,
                color: cs.error,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// ------------------------------
/// COMPACT CATEGORY CHIP
/// ------------------------------

class _CompactBigCategoryChip extends StatelessWidget {
  final String label;
  final String image;
  final bool selected;
  final bool isSecondary;
  final bool isChild;

  const _CompactBigCategoryChip({
    super.key,
    required this.label,
    required this.image,
    this.selected = false,
    this.isSecondary = false,
    this.isChild = false,
  });

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final isDark = Theme.of(context).brightness == Brightness.dark;

    Color bgColor;
    Color fgColor;
    Color borderColor;

    if (selected) {
      bgColor = isDark ? Colors.white : Colors.black;
      fgColor = isDark ? Colors.black : Colors.white;
      borderColor = fgColor;
    } else if (isChild) {
      bgColor = cs.surfaceContainerHighest;
      fgColor = cs.onSurface.withOpacity(0.75);
      borderColor = cs.outlineVariant.withOpacity(0.5);
    } else if (isSecondary) {
      bgColor = cs.surfaceContainer;
      fgColor = cs.onSurface.withOpacity(0.85);
      borderColor = cs.outlineVariant;
    } else {
      bgColor = cs.surface;
      fgColor = cs.onSurface;
      borderColor = cs.outlineVariant;
    }

    return AnimatedContainer(
      duration: const Duration(milliseconds: 200),
      width: 80, // ✅ narrower
      height: 70, // ✅ taller
      // padding: const EdgeInsets.symmetric(horizontal: 2, vertical: 6),
      decoration: BoxDecoration(
        color: bgColor,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: borderColor),
        boxShadow: selected
            ? [
          BoxShadow(
            color: cs.shadow.withOpacity(0.18),
            blurRadius: 8,
            offset: const Offset(0, 4),
          ),
        ]
            : null,
      ),
      child: Column(
        children: [
          // 🖼️ Image with top corners rounded only
          ClipRRect(
            borderRadius: const BorderRadius.only(
              topLeft: Radius.circular(12),
              topRight: Radius.circular(12),
            ),
            child: SizedBox(
              height: 45,
              width: 80,
              child: Image.network(
                "${ApiService.ImagebaseUrl}${ApiService.category_images_URL}$image",
                fit: BoxFit.cover,
              ),
            ),
          ),

          const SizedBox(height: 2),

          // 📝 Text
          Expanded(
            child: Text(
              label,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              textAlign: TextAlign.center,
              style: TextStyle(
                color: fgColor,
                fontSize: 10,
                fontWeight: selected ? FontWeight.w700 : FontWeight.w600,
                height: 1.3,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _CompactCategoryChip extends StatelessWidget {
  final String label;
  final bool selected;
  final bool isSecondary;
  final bool isChild;

  const _CompactCategoryChip({
    required this.label,
    this.selected = false,
    this.isSecondary = false,
    this.isChild = false,
  });

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final isDark = Theme.of(context).brightness == Brightness.dark;

    Color bgColor;
    Color fgColor;
    Color borderColor;

    if (selected) {
      bgColor = isDark ? Colors.white : Colors.black;
      fgColor = isDark ? Colors.black : Colors.white;
      borderColor = isDark ? Colors.white : Colors.black;
    } else if (isChild) {
      bgColor = cs.surfaceContainerHighest;
      fgColor = cs.onSurface.withOpacity(0.7);
      borderColor = cs.outlineVariant.withOpacity(0.5);
    } else if (isSecondary) {
      bgColor = cs.surfaceContainer;
      fgColor = cs.onSurface.withOpacity(0.8);
      borderColor = cs.outlineVariant;
    } else {
      bgColor = cs.surface;
      fgColor = cs.onSurface;
      borderColor = cs.outlineVariant;
    }

    return AnimatedContainer(
      duration: const Duration(milliseconds: 200),
      padding: EdgeInsets.symmetric(
        horizontal: isChild ? 10 : 12,
        vertical: isChild ? 6 : 8,
      ),
      decoration: BoxDecoration(
        color: bgColor,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: borderColor, width: 1),
        boxShadow: selected
            ? [
          BoxShadow(
            color: cs.shadow.withOpacity(0.15),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ]
            : null,
      ),
      child: Text(
        label,
        style: TextStyle(
          color: fgColor,
          fontSize: isChild ? 11 : 12,
          fontWeight: selected ? FontWeight.w700 : FontWeight.w600,
        ),
      ),
    );
  }
}

/// ------------------------------
/// PROMO CARD
/// ------------------------------
class _PromoCardDynamic extends StatelessWidget {
  final BannerModel banner;
  const _PromoCardDynamic({required this.banner});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Container(
      width: 240,
      decoration: BoxDecoration(
        color: isDark ? Colors.white38 : Colors.black12,
        borderRadius: BorderRadius.circular(14),
        boxShadow: [
          BoxShadow(
            color: cs.shadow.withOpacity(0.08),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(14),
        child: Image.network(
          "${ApiService.ImagebaseUrl}${ApiService.banner_images_URL}${banner.image}",
          width: 240,
          height: double.infinity,
          fit: BoxFit.cover,
          loadingBuilder: (context, child, loadingProgress) {
            if (loadingProgress == null) return child;
            return Shimmer.fromColors(
              baseColor: Colors.grey.shade300,
              highlightColor: Colors.grey.shade100,
              child: Container(width: 240, color: Colors.grey),
            );
          },
          errorBuilder: (_, __, ___) =>
              Image.asset('assets/images/banner_error.png', fit: BoxFit.cover),
        ),
      ),
    );
  }
}

/// ------------------------------
/// PRODUCT CARD COMPACT
/// ------------------------------
class _ProductCardCompact extends StatelessWidget {
  final ProductModel product;
  const _ProductCardCompact({required this.product});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final tt = Theme.of(context).textTheme;

    final bool hasDiscount =
        product.discountPrice != null && product.discountPrice != product.price;

    final bool outOfStock = product.availableQuantity <= 0;

    return InkWell(
      borderRadius: BorderRadius.circular(12),
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => ProductDetailScreen(productId: product.id),
          ),
        );
      },
      child: Container(
        decoration: BoxDecoration(
          color: cs.surface,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: cs.outlineVariant),
          boxShadow: [
            BoxShadow(
              color: cs.shadow.withOpacity(0.06),
              blurRadius: 8,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            /// IMAGE + BADGES
            Expanded(
              child: Stack(
                children: [
                  ClipRRect(
                    borderRadius: const BorderRadius.vertical(
                      top: Radius.circular(12),
                    ),
                    child: Image.network(
                      "${ApiService.ImagebaseUrl}/${ApiService.product_images_URL}${product.image}",
                      fit: BoxFit.cover,
                      width: double.infinity,
                      errorBuilder: (_, __, ___) => Container(
                        color: cs.surfaceContainerHighest,
                        child: Icon(
                          Icons.image_not_supported,
                          size: 40,
                          color: cs.onSurface.withOpacity(0.3),
                        ),
                      ),
                    ),
                  ),

                  /// OUT OF STOCK
                  if (outOfStock)
                    Positioned.fill(
                      child: Container(
                        decoration: BoxDecoration(
                          color: Colors.black.withOpacity(0.45),
                          borderRadius: const BorderRadius.vertical(
                            top: Radius.circular(12),
                          ),
                        ),
                        alignment: Alignment.center,
                        child: Text(
                          "OUT OF STOCK",
                          style: tt.labelLarge?.copyWith(
                            color: Colors.white,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                    ),

                  /// DISCOUNT BADGE
                  if (hasDiscount)
                    Positioned(
                      top: 8,
                      left: 8,
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 8,
                          vertical: 4,
                        ),
                        decoration: BoxDecoration(
                          color: cs.primary,
                          borderRadius: BorderRadius.circular(6),
                        ),
                        child: Text(
                          "SALE",
                          style: tt.labelSmall?.copyWith(
                            color: cs.onPrimary,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                    ),
                ],
              ),
            ),

            /// DETAILS
            Padding(
              padding: const EdgeInsets.all(8),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  /// CATEGORY
                  Text(
                    product.subCategory.name,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: tt.labelSmall?.copyWith(
                      color: cs.onSurface.withOpacity(0.5),
                    ),
                  ),

                  const SizedBox(height: 2),

                  /// PRODUCT NAME
                  Text(
                    product.name,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: tt.bodySmall?.copyWith(
                      fontWeight: FontWeight.w600,
                      height: 1.3,
                    ),
                  ),

                  const SizedBox(height: 6),

                  /// PRICE ROW
                  Row(
                    children: [
                      Text(
                        "${product.discountPrice ?? product.price}TJS",
                        style: tt.bodyMedium?.copyWith(
                          color: cs.primary,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      if (hasDiscount) const SizedBox(width: 4),

                      if (hasDiscount)
                        Text(
                          "${product.price}TJS",
                          style: tt.bodySmall?.copyWith(

                              decoration: TextDecoration.lineThrough,
                              color: cs.onSurface.withOpacity(0.5),
                              fontSize: 8
                          ),
                        ),
                    ],
                  ),

                  const SizedBox(height: 4),

                  /// DELIVERY INFO (optional)
                  if (product.deliveryAvailable)
                    Row(
                      children: [
                        Icon(
                          Icons.local_shipping,
                          size: 14,
                          color: cs.onSurface.withOpacity(0.6),
                        ),
                        const SizedBox(width: 4),
                        Text(
                          product.deliveryTime,
                          style: tt.labelSmall?.copyWith(
                            color: cs.onSurface.withOpacity(0.6),
                          ),
                        ),
                      ],
                    ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// ------------------------------
/// SHIMMERS
/// ------------------------------
class _PromoCardShimmer extends StatelessWidget {
  const _PromoCardShimmer();

  @override
  Widget build(BuildContext context) {
    return Shimmer.fromColors(
      baseColor: Colors.grey.shade300,
      highlightColor: Colors.grey.shade100,
      child: Container(
        width: 240,
        decoration: BoxDecoration(
          color: Colors.grey,
          borderRadius: BorderRadius.circular(14),
        ),
      ),
    );
  }
}

class _CategoryScrollShimmer extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;

    return ListView.separated(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      scrollDirection: Axis.horizontal,
      itemBuilder: (_, __) => Shimmer.fromColors(
        baseColor: cs.surfaceContainerHighest,
        highlightColor: cs.surface,
        child: Container(
          height: 38,
          width: 80,
          decoration: BoxDecoration(
            color: Colors.grey,
            borderRadius: BorderRadius.circular(20),
          ),
        ),
      ),
      separatorBuilder: (_, __) => const SizedBox(width: 8),
      itemCount: 5,
    );
  }
}

class _ProductGridShimmer extends StatelessWidget {
  const _ProductGridShimmer();

  @override
  Widget build(BuildContext context) {
    return SliverPadding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      sliver: SliverGrid(
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          mainAxisSpacing: 10,
          crossAxisSpacing: 10,
          childAspectRatio: 0.75,
        ),
        delegate: SliverChildBuilderDelegate(
              (_, __) => Shimmer.fromColors(
            baseColor: Colors.grey.shade300,
            highlightColor: Colors.grey.shade100,
            child: Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12),
              ),
            ),
          ),
          childCount: 6,
        ),
      ),
    );
  }
}

class _StoreCard extends StatelessWidget {
  final StoreModel store;
  const _StoreCard({required this.store});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final tt = Theme.of(context).textTheme;

    return InkWell(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) =>
                StoreDetailScreen(storeId: store!.id, storeName: store!.name),
          ),
        );
      },
      child: Container(
        width: 220,
        decoration: BoxDecoration(
          color: cs.surface,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: cs.outlineVariant),
          boxShadow: [
            BoxShadow(
              color: cs.shadow.withOpacity(0.06),
              blurRadius: 10,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            /// LOGO
            ClipRRect(
              borderRadius: const BorderRadius.vertical(
                top: Radius.circular(14),
              ),
              child: store.logo != null
                  ? Image.network(
                "${ApiService.ImagebaseUrl}/${ApiService.store_logo_URL}${store.logo}",
                height: 120,
                width: double.infinity,
                fit: BoxFit.cover,
              )
                  : Container(
                height: 120,
                color: cs.surfaceContainerHighest,
                child: Center(
                  child: Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: cs.primary.withOpacity(0.1),
                      shape: BoxShape.circle,
                    ),
                    child: Icon(
                      Icons.storefront_rounded,
                      size: 50,
                      color: cs.primary,
                    ),
                  ),
                ),
              ),
            ),

            Padding(
              padding: const EdgeInsets.all(10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    store.name,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: tt.bodyMedium?.copyWith(fontWeight: FontWeight.w700),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    store.city,
                    style: tt.bodySmall?.copyWith(
                      color: cs.onSurface.withOpacity(0.6),
                    ),
                  ),
                  const SizedBox(height: 2),

                  Text(
                    store.description.toString(),
                    overflow: TextOverflow.ellipsis,
                    style: tt.bodySmall?.copyWith(
                      color: cs.onSurface.withOpacity(0.6),
                    ),
                  ),
                  const SizedBox(height: 2),
                  Row(
                    children: [
                      Icon(Icons.access_time, size: 14, color: cs.primary),
                      const SizedBox(width: 4),
                      Text(
                        store.workingHours,
                        style: tt.labelSmall?.copyWith(color: cs.primary),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
class _AutoBannerSlider extends StatefulWidget {
  final List<BannerModel> banners;
  const _AutoBannerSlider({required this.banners});

  @override
  State<_AutoBannerSlider> createState() => _AutoBannerSliderState();
}

class _AutoBannerSliderState extends State<_AutoBannerSlider> {
  final PageController _controller = PageController(viewportFraction: 0.92);
  int _currentIndex = 0;

  @override
  void initState() {
    super.initState();

    Future.delayed(const Duration(seconds: 3), _autoScroll);
  }

  void _autoScroll() async {
    while (mounted) {
      await Future.delayed(const Duration(seconds: 3));

      if (!mounted) return;

      _currentIndex++;
      if (_currentIndex >= widget.banners.length) {
        _currentIndex = 0;
      }

      _controller.animateToPage(
        _currentIndex,
        duration: const Duration(milliseconds: 600),
        curve: Curves.easeInOut,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Expanded(
          child: PageView.builder(
            controller: _controller,
            itemCount: widget.banners.length,
            onPageChanged: (index) {
              setState(() => _currentIndex = index);
            },
            itemBuilder: (_, i) {
              return Padding(
                padding: const EdgeInsets.symmetric(horizontal: 6),
                child: _BigPromoCard(banner: widget.banners[i]),
              );
            },
          ),
        ),

        const SizedBox(height: 8),

        /// 🔵 Indicator
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: List.generate(
            widget.banners.length,
                (index) => AnimatedContainer(
              duration: const Duration(milliseconds: 300),
              margin: const EdgeInsets.symmetric(horizontal: 4),
              height: 6,
              width: _currentIndex == index ? 18 : 6,
              decoration: BoxDecoration(
                color: _currentIndex == index
                    ? Colors.black
                    : Colors.grey.shade400,
                borderRadius: BorderRadius.circular(20),
              ),
            ),
          ),
        ),
      ],
    );
  }
}
class _BigPromoCard extends StatelessWidget {
  final BannerModel banner;
  const _BigPromoCard({required this.banner});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(18),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.08),
            blurRadius: 16,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(18),
        child: Image.network(
          "${ApiService.ImagebaseUrl}${ApiService.banner_images_URL}${banner.image}",
          fit: BoxFit.cover,
          width: double.infinity,
          loadingBuilder: (context, child, progress) {
            if (progress == null) return child;

            return Shimmer.fromColors(
              baseColor: Colors.grey.shade300,
              highlightColor: Colors.grey.shade100,
              child: Container(color: Colors.grey),
            );
          },
          errorBuilder: (_, __, ___) =>
              Image.asset("assets/images/banner_error.png", fit: BoxFit.cover),
        ),
      ),
    );
  }
}
class _PromoBannerShimmer extends StatelessWidget {
  const _PromoBannerShimmer();

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Shimmer.fromColors(
        baseColor: Colors.grey.shade300,
        highlightColor: Colors.grey.shade100,
        child: Container(
          height: 180,
          decoration: BoxDecoration(
            color: Colors.grey,
            borderRadius: BorderRadius.circular(18),
          ),
        ),
      ),
    );
  }
}
